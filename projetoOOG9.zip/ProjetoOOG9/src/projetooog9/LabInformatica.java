package user;

public class LabInformatica extends laboratorio{
    
    private int qtdComputadores;

    public int getQtdComputadores() {
        return qtdComputadores;
    }
    public void setQtdComputadores(int qtdComputadores) {
        this.qtdComputadores = qtdComputadores;
    }
}
