package user;

public class LabEletronica extends laboratorio {
    
    private int qtdKits;

    public int getQtdKits() {
        return qtdKits;
    }
    public void setQtdKits(int qtdKits) {
        this.qtdKits = qtdKits;
    }
}
