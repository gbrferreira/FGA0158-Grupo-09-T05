package Aplicativo;

import com.mycompany.fgarooms.user.Sala;

public class laboratorio extends Sala {
    
    private String tipo;

    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
