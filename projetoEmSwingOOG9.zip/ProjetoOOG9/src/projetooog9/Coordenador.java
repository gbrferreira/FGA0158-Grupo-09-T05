package user;

public class Coordenador extends Usuario {
    
    public void aceitarReserva(){
        // a fazer
    }

    public void criarTurma(){
        // a fazer
    }

    public void editarTurma(){
        // a fazer
    }
}
