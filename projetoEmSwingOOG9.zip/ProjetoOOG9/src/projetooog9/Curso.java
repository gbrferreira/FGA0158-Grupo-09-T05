package user;

public class Curso {

    private String nome;
    private int qtdAlunos;

    public int calcularQtdAlunos(){
        //a fazer
        return 5;
    }

    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getQtdAlunos() {
        return qtdAlunos;
    }
    public void setQtdAlunos(int qtdAlunos) {
        this.qtdAlunos = qtdAlunos;
    }

}
