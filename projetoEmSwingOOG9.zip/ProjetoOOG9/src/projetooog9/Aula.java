package user;
import java.util.*;

public class Aula {
    
    private Date horario;

    public Date getHorario() {
        return horario;
    }

    public void setHorario(Date horario) {
        this.horario = horario;
    }
}
